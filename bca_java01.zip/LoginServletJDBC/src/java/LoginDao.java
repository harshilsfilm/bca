/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
import java.sql.*;
public class LoginDao {
    public static boolean validate(String user,String pass)
    {
        boolean status=false;
    try
    {
         Class.forName("com.mysql.cj.jdbc.Driver");
         Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3309/aj","root","");
         String selectQuery="Select * from userreg where username=? and password=?";
         PreparedStatement ps=con.prepareStatement(selectQuery);
         ps.setString(1, user);
         ps.setString(2, pass);
         ResultSet rs=ps.executeQuery();
         status=rs.next();
    }
    catch(ClassNotFoundException | SQLException e)
    {
        System.out.println("e");
    }
    return status;
    }
}
