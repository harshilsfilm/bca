/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Users;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Administrator
 */
public class UserDAO {
    public static List<Users> getAllUsers() {
        List<Users> list = new ArrayList<>();
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3309/aj","root","");
             PreparedStatement ps=con.prepareStatement("select *from users");
             ResultSet rs=ps.executeQuery();
             while(rs.next()){
                 Users u=new Users();
                 u.setId(rs.getInt("id"));;
                 u.setUsername(rs.getString("username"));
                 u.setEmail(rs.getString("email"));
                 list.add(u);
                 
             }
             
            
        }
        catch(Exception e)
        {
            
        }
        return list;
    }
}
