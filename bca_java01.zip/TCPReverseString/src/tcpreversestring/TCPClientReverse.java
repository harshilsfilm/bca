/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpreversestring;
import java.net.*;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class TCPClientReverse {
    public static void main(String args[])
    {
        try
        {
            Socket s=new Socket("localhost",5000);
            
            BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            
            Scanner sc=new Scanner(System.in);
            
            System.out.println("Enter Input String");
            
            String str=sc.next();
            
            out.println(str);
            
            String ans=br.readLine();
            
            System.out.println("Reverse String send by server:" + ans);
            
            s.close();
            
            

        }
        catch(Exception e)
        {
            
        }
        
    }
    
}
