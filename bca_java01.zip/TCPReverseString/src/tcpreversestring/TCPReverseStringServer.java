/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpreversestring;
import java.net.*;
import java.io.*;
/**
 *
 * @author Administrator
 */
public class TCPReverseStringServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try
        {
            ServerSocket ss=new ServerSocket(5000);
            Socket s=ss.accept();
            System.out.println("Client connected");
            
            BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            
            String str=br.readLine();
            
            System.out.println("Client send:" + str);
            
            String rev=new StringBuffer(str).reverse().toString();
            
            System.out.println("String Reverse send to client:" + rev);
            
            out.println(rev);
            
            s.close();
            ss.close();
            
            
            
            
        }
        catch(Exception e)
        {
            
        }
    }
    
}
