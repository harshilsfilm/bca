/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package updateselect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class UpdateSelect {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3309/aj","root", "");
            System.out.println("Connection Established");
            
            String selectQuery="update employee set name=?,department=? where id=?";
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter Id");
            int id1=sc.nextInt();
             System.out.println("Enter Name");
           String name=sc.next();
            System.out.println("Enter Department");
           String dept=sc.next();
            PreparedStatement ps=con.prepareStatement(selectQuery);
               ps.setString(1, name);
            ps.setString(2, dept);
            ps.setInt(3,id1);
          int state=ps.executeUpdate();
           
          if(state>0)
          {
              System.out.println("Data Updated Successfully");
          
          }
         else
          {
               System.out.println("Data not Updated Successfully");
          }
                  
            
        }
        catch(ClassNotFoundException e)
        {
            
        }
        catch(SQLException e)
        {
            
        }
        
    }
    
}
