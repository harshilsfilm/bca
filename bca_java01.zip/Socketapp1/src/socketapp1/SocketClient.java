/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socketapp1;
import java.net.*;
import java.io.*;
/**
 *
 * @author Administrator
 */
public class SocketClient {
    public static void main(String args[])
    {
        try
        {
            Socket s=new Socket("localhost",5000);
             BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            out.println("Hello Server");
            
            String msg=br.readLine();
            System.out.println(msg);
            s.close();
        }
        catch(Exception e)
        {
            
        }
    }
}
