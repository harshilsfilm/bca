/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringreversetcp;
import java.net.*;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class StringReverseClient {
    
    public static void main(String args[])
    {
        try
        {
            Socket s=new Socket("localhost",5000);
            
            Scanner sc=new Scanner(System.in);
            
            System.out.println("Please enter string is to be reversed:");
            String str=sc.next();
            
            System.out.println("String send to server:"+ str);
             
            BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            
            out.println(str);
            
            String rev=br.readLine();
            
            System.out.println("String reverse received from server:" + rev);
            
            s.close();
            
            
            
            
        }
        catch(Exception e)
        {
            
        }
    }
}

