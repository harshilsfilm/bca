/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udpsocket;
import java.net.*;
/**
 *
 * @author Administrator
 */
public class UDPSender {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try
        {
            String msg="Hello";
            InetAddress ip=InetAddress.getByName("127.0.0.1");
            DatagramPacket dp=new DatagramPacket(msg.getBytes(),msg.length(),ip,5000);
            DatagramSocket ds=new DatagramSocket();      
            ds.send(dp);
            ds.close();
        }
        catch(Exception e)
        {
            
        }
    }
    
}
