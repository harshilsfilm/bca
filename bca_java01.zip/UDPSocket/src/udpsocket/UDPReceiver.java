/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udpsocket;
import java.net.*;
/**
 *
 * @author Administrator
 */
public class UDPReceiver {
    public static void  main(String args[])
    {
        try
        {
            byte buf[]=new byte[1024];
            DatagramPacket dp=new DatagramPacket(buf,1024);
            DatagramSocket ds=new DatagramSocket(5000);
            ds.receive(dp);
            String str=new String(dp.getData(),0,dp.getLength());
            System.out.println(str);
            ds.close();
        }
        catch(Exception e)
        {
            
        }
        
    }
    
}
