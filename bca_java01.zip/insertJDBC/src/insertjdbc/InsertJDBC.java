/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insertjdbc;
import java.sql.*;
import java.util.*;

/**
 *
 * @author Administrator
 */
public class InsertJDBC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         String url = "jdbc:mysql://localhost:3309/aj"; // Replace with your DB
        String user = "root";         // Replace with your username
        String password = ""; // Replace with your password

        Connection conn = null;
        Statement stmt = null;
        Scanner scanner = new Scanner(System.in);

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
            System.out.println("Connected to the database...");

           
                        System.out.print("Enter ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Department: ");
                        String dept = scanner.nextLine();

                        String insertSQL = "INSERT INTO employee (id, name, department) " +
                                           "VALUES (" + id + ", '" + name + "', '" + dept + "')";
                        int insertResult = stmt.executeUpdate(insertSQL);
                        System.out.println(insertResult + " record(s) inserted.");
                      
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL Exception.");
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
                scanner.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
}
