/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udpadd;
import java.net.*;
/**
 *
 * @author Administrator
 */
public class UDPAddServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try
        {
            DatagramSocket ds=new DatagramSocket(1111);
            
            byte[] no1=new byte[1024];
            DatagramPacket dp1=new DatagramPacket(no1, 1024);
            ds.receive(dp1);
            
            String number1=new String(dp1.getData(),0,dp1.getLength());
            int n1=Integer.parseInt(number1);
            
            byte[] no2=new byte[1024];
            DatagramPacket dp2=new DatagramPacket(no2, 1024);
            ds.receive(dp2);
            
            String number2=new String(dp2.getData(),0,dp2.getLength());
             int n2=Integer.parseInt(number2);
            
            System.out.println("Client send No1:" + n1);
            System.out.println("Client send No2:" + n2);
            
            int sum=n1+n2;
            
            System.out.println("Addition to send client : "+ sum);
            
            InetAddress ip=dp2.getAddress();
            int port=dp2.getPort();
            
            String ans=String.valueOf(sum);
            
            DatagramPacket dpsend=new DatagramPacket(ans.getBytes(),ans.length(),ip, port);
            ds.send(dpsend);
            
            ds.close();
            
            
            
            
        }
        catch(Exception e)
        {
            
        }
    }
    
}
