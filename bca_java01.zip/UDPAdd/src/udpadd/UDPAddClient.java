/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udpadd;
import java.net.*;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class UDPAddClient {
    public static void main(String args[])
    {
        try
        {
            DatagramSocket ds=new DatagramSocket();
            
            Scanner sc=new Scanner(System.in);
            
            System.out.println("Enter No1:");
            String no1=sc.next();
            
            System.out.println("Enter No2:");
            String no2=sc.next();
            
            InetAddress ip=InetAddress.getByName("localhost");
            
            DatagramPacket dp1=new DatagramPacket(no1.getBytes(), no1.length(),ip,1111);
            ds.send(dp1);
            
            DatagramPacket dp2=new DatagramPacket(no2.getBytes(), no2.length(),ip,1111);
            ds.send(dp2);
            
            
            byte ans[]=new byte[1024];
            
            DatagramPacket dpreceive=new DatagramPacket(ans,1024);
            ds.receive(dpreceive);
            
            String reply=new String(dpreceive.getData(),0,dpreceive.getLength());
            
            System.out.println("Sum received from server:"+ reply);
            ds.close();
       
            
        }
        catch(Exception e)
        {
            
        }
    }
    
}
