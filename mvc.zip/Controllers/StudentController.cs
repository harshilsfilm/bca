﻿using mvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvc.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            List<Student> students = new List<Student>()
            {
                new Student() { Id=1, Name="Harshil", marks=50 },
                new Student() { Id=2, Name="Kirtan", marks=40 },
                new Student() { Id=3, Name="Jenish", marks=30 }

            };
            return View(students);
        }
        public ActionResult About()
        {
            ViewBag.Message = "Welcome to MVC view";
            return View();
        }
    }
}