import 'package:flutter/material.dart';

class ExpenseHomePage extends StatefulWidget {
  @override
  _ExpenseHomePageState createState() => _ExpenseHomePageState();
}

class _ExpenseHomePageState extends State<ExpenseHomePage> {
  // Map a = {
  // "":""
  // };

  final TextEditingController titleController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  DateTime? selectedDate;

  bool isEditing = false;
  int? editingIndex;

  void presentDatePicker() async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (pickedDate != null) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }

  final List<Map<String, dynamic>> expenses = [];

  void submitData() {

    final enteredTitle = titleController.text.trim();
    final enteredAmount = double.tryParse(amountController.text.trim());

    if (enteredTitle.isEmpty || enteredAmount == null || enteredAmount <= 0 || selectedDate == null) {
      showError("Please enter valid title, amount, and date.");
      return;
    }

    if (isEditing && editingIndex != null) {
      // Editing existing item
      setState(() {
        expenses[editingIndex!] = {
          'title': enteredTitle,
          'amount': enteredAmount,
          'date': selectedDate!,
        };
        resetForm();
      });
    } else {
      // Adding new item
      setState(() {
        expenses.add({
          'title': enteredTitle,
          'amount': enteredAmount,
          'date': selectedDate!,
        });

        //Expanses = [{"title":"Test","amount": 500,"date": 28-08-2025},]
        resetForm();
      });
    }
  }

  void resetForm() {
    titleController.clear();
    amountController.clear();
    selectedDate = null;
    isEditing = false;
    editingIndex = null;
  }

  void showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void deleteExpense(int index) {
    setState(() {
      expenses.removeAt(index);
    });
  }

  void startEditing(int index) {
    final exp = expenses[index];
    setState(() {
      isEditing = true;
      editingIndex = index;
      titleController.text = exp['title'];
      amountController.text = exp['amount'].toString();
      selectedDate = exp['date'];
    });
  }

  String getFormattedDate(DateTime date) {
    return '${date.day}-${date.month}-${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expense App'),

      ),
      body: Column(
        children: [
          // Form Section
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    // Text("$pickedDate"),
                    TextField(
                      controller: titleController,
                      decoration: InputDecoration(labelText: 'Title'),
                    ),
                    TextField(
                      controller: amountController,
                      decoration: InputDecoration(
                          labelText: 'Amount',
                          prefixText: '\₹'),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                    ),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          selectedDate == null
                              ? 'No Date Chosen!'
                              : 'Picked Date: ${getFormattedDate(selectedDate!)}',
                        ),
                        IconButton(
                          icon: Icon(Icons.calendar_today),
                          onPressed: presentDatePicker,
                        ),
                      ],
                    ),
                    ElevatedButton(
                      onPressed: submitData,
                      child: Text(isEditing ? 'Update Expense' : 'Add Expense'),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // List Section
          Expanded(
            child: expenses.isEmpty
                ? Center(child: Text('No expenses yet!'))
                : ListView.builder(
              itemCount: expenses.length,
              itemBuilder: (ctx, index) {
                final exp = expenses[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  elevation: 3,
                  child: ListTile(

                    title: Text(exp['title'], style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Row(
                      children: [
                        Container(
                          child: FittedBox(child: Text('\₹${exp['amount'].toStringAsFixed(2)}')),
                        ),

                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Container(
                            height: 15,
                            width: 1,
                            color: Colors.black,
                          ),
                        ),
                        Text('${getFormattedDate(exp['date'])}'),
                      ],
                    ),
                    trailing: Wrap(
                      spacing: 8,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit, color: Colors.blue),
                          onPressed: () => startEditing(index),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed:() =>  deleteExpense(index),
                        ),
                      ],
                    ),
                  ),
                );
                // return ExpenseItem(
                //   title: exp['title'],
                //   amount: exp['amount'],
                //   date: exp['date'],
                //   onEdit: () => startEditing(index),
                //   onDelete: () => deleteExpense(index),
                // );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ExpenseItem extends StatelessWidget {
  final String title;
  final double amount;
  final DateTime date;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  ExpenseItem({
    required this.title,
    required this.amount,
    required this.date,
    required this.onEdit,
    required this.onDelete,
  });

  String getFormattedDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}-${date.month.toString().padLeft(2, '0')}-${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      elevation: 3,
      child: ListTile(

        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Row(
          children: [
            Container(
              child: FittedBox(child: Text('\₹${amount.toStringAsFixed(2)}')),
            ),

            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Container(
                height: 15,
                width: 1,
                color: Colors.black,
              ),
            ),
            Text('${getFormattedDate(date)}'),
          ],
        ),
        trailing: Wrap(
          spacing: 8,
          children: [
            IconButton(
              icon: Icon(Icons.edit, color: Colors.blue),
              onPressed: onEdit,
            ),
            IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: onDelete,
            ),
          ],
        ),
      ),
    );
  }
}
