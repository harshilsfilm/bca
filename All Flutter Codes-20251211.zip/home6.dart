import 'package:flutter/material.dart';
import 'package:lj/home25a.dart';

class Home6 extends StatefulWidget {
   Home6({super.key});

  @override
  State<Home6> createState() => _Home6State();
}

class _Home6State extends State<Home6> {
  int a =0;
  TextEditingController nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [

            InkWell(
              onTap: (){

              },
              child: CircleAvatar(
                radius: 120,
                backgroundColor: Colors.blue,
                backgroundImage: NetworkImage(
                    "https://hips.hearstapps.com/hmg-prod/images/dog-puppy-on-garden-royalty-free-image-1586966191.jpg?crop=1xw:0.74975xh;0,0.190xh&resize=1200:*"),
              ),
            ),

            // Image.asset("assets/images/1000070722.png",
            //   height: 200,
            //   width: 200,
            // ),

            // Image.network("https://hips.hearstapps.com/hmg-prod/images/dog-puppy-on-garden-royalty-free-image-1586966191.jpg?crop=1xw:0.74975xh;0,0.190xh&resize=1200:*",
            // height: 200,
            //   width: 200,
            // ),

            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Container(
                width: 200,
                child: TextField(
                  controller: nameController,
                  // maxLines: 3,
                  decoration: InputDecoration(
                      prefixIcon: Icon(Icons.person),
                      // suffixIcon: Icon(Icons.person),
                      label: Text("Enter Your Name"),
                      hintText: "Enter Name",
                      // helperText: "Enter Name",
                      //  border: OutlineInputBorder(
                      //    borderSide: BorderSide(
                      //      color: Colors.orange
                      //    )
                      //  ),
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.orange
                          )
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.greenAccent
                          )
                      )
                  ),
                ),
              ),
            ),
            Text("$a ${nameController.text}"),
            ElevatedButton(
                onPressed: (){
                  // setState(() {
                  //   a++;
                  // });
                  Navigator.push(
                      context, MaterialPageRoute(
                      builder: (context) => Home25A())
                  );
                  // Navigator.pop(context);
                },

                child: Text("Next Screen")),

            // Row(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     Text("Don't Have an Account??"),
            //     InkWell(
            //       onTap: (){
            //
            //       },
            //         child: Text("Sign Up")
            //     ),
            //     // TextButton(onPressed: (){
            //     //
            //     // },
            //     //
            //     //   child:Text("Sign Up"),
            //     // )
            //
            //   ],
            // )
          ],
        ),
      ),
    );
  }
}
