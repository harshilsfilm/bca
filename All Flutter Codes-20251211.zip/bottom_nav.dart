import 'package:flutter/material.dart';
import 'package:lj/class_a/calculator.dart';
import 'package:lj/class_a/expense_app.dart';
import 'package:lj/class_a/get_api/get_screen.dart';
import 'package:lj/class_b/bmi_calculator.dart';
import 'package:lj/class_b/expanse_app.dart';

class BottomNavScreen extends StatefulWidget {
  @override
  _BottomNavScreenState createState() => _BottomNavScreenState();
}

class _BottomNavScreenState extends State<BottomNavScreen> {
  int currentIndex = 0;
  List Screens = [
    Calculator(),
    PostsPage(),
    BMICalculator(),
  ];
  void ontapp(int index){
    setState(() {
      currentIndex = index;
    }); 
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bottom Navigation Example'),
      ),
      body: Screens[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
          onTap: ontapp,
          items: [
            BottomNavigationBarItem(
                icon: Icon(Icons.house_sharp,),
              label: "Home"
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.people_rounded),
              label: "Profile"
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.house_sharp),
                label: "Home"
            ),
          ]
      ),
    );
  }
}
