import 'package:flutter/material.dart';
import 'dart:math';

class BMICalculator extends StatefulWidget {
  @override
  _BMICalculatorState createState() => _BMICalculatorState();
}

class _BMICalculatorState extends State<BMICalculator> {


  final TextEditingController heightController = TextEditingController();
  final TextEditingController weightController = TextEditingController();

  double Bmi = 0;
  String Message = "";

  void calculateBMI() {
    final heightText = heightController.text.trim();
    final weightText = weightController.text.trim();

    if (heightText.isEmpty || weightText.isEmpty) {
      _showError("Please enter both height and weight.");
      return;
    }

    final double? height = double.tryParse(heightText);
    final double? weight = double.tryParse(weightText);

    if (height == null || weight == null || height <= 0 || weight <= 0) {
      _showError("Please enter valid positive numbers.");
      return;
    }

    double bmi = weight / pow(height / 100, 2);

    String message;
    if (bmi < 18.5) {
      message = "Underweight";
    } else if (bmi < 24.9) {
      message = "Normal weight";
    } else if (bmi < 29.9) {
      message = "Overweight";
    } else {
      message = "Obesity";
    }

    setState(() {
      Bmi = bmi;
      Message = message;
    });
  }

  void _showError(String message) {
    setState(() {
      Bmi = 0;
      Message = "";
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            TextField(
              controller: heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Height (cm)",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Weight (kg)",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: calculateBMI,
              child: Text("Calculate BMI"),
            ),
            SizedBox(height: 30),
            if (Bmi > 0)
              Column(
                children: [
                  Text(
                    "Your BMI is: ${Bmi.toStringAsFixed(2)}",
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    Message,
                    style: TextStyle(fontSize: 20, color: Colors.grey[700]),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
