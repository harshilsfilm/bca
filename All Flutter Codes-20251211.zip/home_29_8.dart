import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
   HomePage({super.key});

   List A = ["1","2","3"];
   List B = [Colors.blue,Colors.orange,Colors.red];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: 500,
        width: 100,
        child: ListView.builder(
          itemCount: A.length,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context,index) {
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: 50,
                width: 200,
                color: B[index]
                // index == 0
                //     ?Colors.blue
                //     :Colors.orange
                ,
                child: Center(child: Text("${A[index]}"),),
              ),
            );
          } ,
          // children: [
          //   Padding(
          //     padding: const EdgeInsets.all(8.0),
          //     child: Container(
          //       height: 100,
          //       width: 100,
          //       color: Colors.blue,
          //     ),
          //   ),
          // ],
        ),
      ),
    );
  }
}
