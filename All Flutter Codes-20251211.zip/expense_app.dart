import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart'; // For date formatting


class ExpenseHomePage extends StatefulWidget {
  @override
  _ExpenseHomePageState createState() => _ExpenseHomePageState();
}

class _ExpenseHomePageState extends State<ExpenseHomePage> {
  List<Map<String, dynamic>> _expenses = [];

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    final savedData = prefs.getString('expenses');
    if (savedData != null) {
      final List decodedList = jsonDecode(savedData);
      setState(() {
        _expenses = decodedList.map<Map<String, dynamic>>((item) {
          return {
            'title': item['title'],
            'amount': item['amount'],
            'date': DateTime.parse(item['date']),
          };
        }).toList();
      });
    }
  }

  Future<void> _saveExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    final String encodedData = jsonEncode(_expenses.map((item) {
      return {
        'title': item['title'],
        'amount': item['amount'],
        'date': (item['date'] as DateTime).toIso8601String(),
      };
    }).toList());
    await prefs.setString('expenses', encodedData);
  }

  void _deleteExpense(int index) {
    setState(() {
      _expenses.removeAt(index);
    });
    _saveExpenses();
  }

  void _openExpenseForm({Map<String, dynamic>? expense, int? index}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (_) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            top: 20,
            left: 20,
            right: 20,
          ),
          child: ExpenseForm(
            existingExpense: expense,
            onSave: (title, amount, date) {
              if (expense != null && index != null) {
                // update
                setState(() {
                  _expenses[index] = {
                    'title': title,
                    'amount': amount,
                    'date': date,
                  };
                });
              } else {
                // add
                setState(() {
                  _expenses.add({
                    'title': title,
                    'amount': amount,
                    'date': date,
                  });
                });
              }
              _saveExpenses();
              Navigator.of(context).pop();
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expense Tracker'),
        centerTitle: true,
        elevation: 0,
      ),
      body: _expenses.isEmpty
          ? Center(
        child: Text(
          'No expenses added yet.\nTap + to add one!',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 18, color: Colors.grey[600]),
        ),
      )
          : ListView.builder(
        padding: EdgeInsets.symmetric(vertical: 8),
        itemCount: _expenses.length,
        itemBuilder: (ctx, i) {
          final exp = _expenses[i];
          return ExpenseCard(
            title: exp['title'],
            amount: exp['amount'],
            date: exp['date'],
            onEdit: () => _openExpenseForm(expense: exp, index: i),
            onDelete: () => _deleteExpense(i),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openExpenseForm(),
        child: Icon(Icons.add),
        tooltip: 'Add Expense',
      ),
    );
  }
}

class ExpenseForm extends StatefulWidget {
  final Map<String, dynamic>? existingExpense;
  final Function(String, double, DateTime) onSave;

  ExpenseForm({this.existingExpense, required this.onSave});

  @override
  _ExpenseFormState createState() => _ExpenseFormState();
}

class _ExpenseFormState extends State<ExpenseForm> {
  final _titleController = TextEditingController();
  final _amountController = TextEditingController();
  DateTime? _pickedDate;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    if (widget.existingExpense != null) {
      _titleController.text = widget.existingExpense!['title'];
      _amountController.text = widget.existingExpense!['amount'].toString();
      _pickedDate = widget.existingExpense!['date'];
    }
  }

  void _presentDatePicker() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _pickedDate ?? now,
      firstDate: DateTime(now.year - 10),
      lastDate: now,
    );
    if (picked != null) {
      setState(() {
        _pickedDate = picked;
      });
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate() || _pickedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please fill all fields and choose a date.'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }
    final title = _titleController.text.trim();
    final amount = double.parse(_amountController.text.trim());
    widget.onSave(title, amount, _pickedDate!);
  }

  @override
  Widget build(BuildContext context) {
    final dateText = _pickedDate == null
        ? 'Choose Date'
        : DateFormat.yMMMd().format(_pickedDate!);

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            widget.existingExpense == null ? 'Add Expense' : 'Edit Expense',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: InputDecoration(labelText: 'Title', prefixIcon: Icon(Icons.title)),
                  validator: (val) {
                    if (val == null || val.trim().isEmpty) {
                      return 'Please enter a title';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 15),
                TextFormField(
                  controller: _amountController,
                  decoration: InputDecoration(
                    labelText: 'Amount',
                    prefixIcon: Icon(Icons.attach_money),
                  ),
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  validator: (val) {
                    if (val == null || val.trim().isEmpty) {
                      return 'Please enter amount';
                    }
                    final numValue = double.tryParse(val);
                    if (numValue == null || numValue <= 0) {
                      return 'Enter a valid positive number';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        dateText,
                        style: TextStyle(fontSize: 16, color: Colors.grey[800]),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: _presentDatePicker,
                      icon: Icon(Icons.calendar_today),
                      label: Text('Select Date'),
                    ),
                  ],
                ),
                SizedBox(height: 30),
                ElevatedButton(
                  onPressed: _submit,
                  child: Text(widget.existingExpense == null ? 'Add Expense' : 'Update Expense'),
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 48),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ExpenseCard extends StatelessWidget {
  final String title;
  final double amount;
  final DateTime date;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  ExpenseCard({
    required this.title,
    required this.amount,
    required this.date,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final dateFormatted = DateFormat.yMMMd().format(date);
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        leading: CircleAvatar(
          radius: 30,
          backgroundColor: Colors.teal.shade300,
          child: Padding(
            padding: const EdgeInsets.all(6.0),
            child: FittedBox(
              child: Text('\$${amount.toStringAsFixed(2)}',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        subtitle: Text(dateFormatted, style: TextStyle(color: Colors.grey[600])),
        trailing: Wrap(
          spacing: 8,
          children: [
            IconButton(
              icon: Icon(Icons.edit, color: Colors.blueGrey),
              onPressed: onEdit,
              tooltip: 'Edit',
            ),
            IconButton(
              icon: Icon(Icons.delete, color: Colors.redAccent),
              onPressed: onDelete,
              tooltip: 'Delete',
            ),
          ],
        ),
      ),
    );
  }
}
