import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

class UserListScreen extends StatelessWidget {
  final Box usersBox = Hive.box("usersBox");

  @override
  Widget build(BuildContext context) {
    AppBar appBar = AppBar(title: Text("Saved Users"));

    ListView listView = ListView.builder(
      itemCount: usersBox.length,
      itemBuilder: (context, index) {
        var user = usersBox.getAt(index);
        return ListTile(
          leading: CircleAvatar(child: Text(user["username"][0])),
          title: Text(user["username"]),
          subtitle: Text("${user["email"]} | ${user["password"]}"),
        );
      },
    );

    Scaffold scaffold = Scaffold(
      appBar: appBar,
      body: listView,
    );

    return scaffold;
  }
}
