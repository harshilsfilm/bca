import 'package:dio/dio.dart';
import 'package:lj/class_c/get_api/get_model.dart';

class ApiService {

  Dio dio = Dio();
  final String baseUrl = 'https://jsonplaceholder.typicode.com/posts';

  Future<List<Post>> fetchPosts() async {

    try {

      final response = await dio.get('$baseUrl');

      if (response.statusCode == 200) {

        List<Post> posts = (response.data as List)
            .map((postJson) => Post.fromJson(postJson))
            .toList();
        return posts;
      } else {
        throw Exception('Failed to load posts');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}
