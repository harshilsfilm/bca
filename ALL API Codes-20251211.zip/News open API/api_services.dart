// news_service.dart
import 'package:dio/dio.dart';
import 'package:lj/class_c/news/news_model.dart';

class NewsService {
  final Dio dio = Dio();
  final String apiUrl = 'https://gnews.io/api/v4/search?q=example&lang=en&country=us&max=10&apikey=b9c7382436b811f3b66d2091f54e9f5a';

  Future<News> fetchNews() async {

    try {
      final response = await dio.get(apiUrl);

      print(response.data);

      if (response.statusCode == 200) {

        return News.fromJson(response.data);
      } else {
        throw Exception('Failed to load news, status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching news: $e');
    }
  }
}