﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;



namespace sqldatabase
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;password=;database=user_detail");
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void Load()
        {
            MySqlDataAdapter ds= new MySqlDataAdapter("Select * from users",conn);
            DataTable dt=new DataTable();
            ds.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }


        protected void Btn_add_Click(object sender, EventArgs e)
        {
            MySqlCommand mySqlCommand = new MySqlCommand("Insert into users(name,email) values(@name,@email)",conn);

            mySqlCommand.Parameters.AddWithValue("@name", TxtName.Text);
            mySqlCommand.Parameters.AddWithValue("@email", TxtEmail.Text);

            conn.Open();
            mySqlCommand.ExecuteNonQuery();
            conn.Close();


        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TxtID.Text = GridView1.SelectedRow.Cells[0].Text;
            TxtName.Text = GridView1.SelectedRow.Cells[1].Text;
            TxtEmail.Text = GridView1.SelectedRow.Cells[2].Text;
        }

        protected void Display_Click(object sender, EventArgs e)
        {
            Load();
        }
    }
}