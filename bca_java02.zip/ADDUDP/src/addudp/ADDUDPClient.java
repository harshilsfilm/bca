/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addudp;
import java.net.*;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class ADDUDPClient {
    public static void main(String args[])
    {
        try
        {
            DatagramSocket ds=new DatagramSocket();
            InetAddress ip=InetAddress.getByName("127.0.0.1");
            
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter no1:");
            String no1=sc.next();
            
            System.out.println("Enter no2:");
            String no2=sc.next();
            
           DatagramPacket dp1=new DatagramPacket(no1.getBytes(), no1.length(),ip,111);
           ds.send(dp1);
           
           
            DatagramPacket dp2=new DatagramPacket(no2.getBytes(), no2.length(),ip,111);
           ds.send(dp2);
            
        }
        catch(Exception e)
        {
        }
        
    }
    
}
