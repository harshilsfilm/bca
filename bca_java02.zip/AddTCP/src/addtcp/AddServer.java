/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addtcp;
import java.net.*;
import java.io.*;

/**
 *
 * @author Administrator
 */
public class AddServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try
        {
            ServerSocket ss=new ServerSocket(5000);
            Socket s=ss.accept();
            System.out.println("Client Connected");
            
            BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            
            int no1=Integer.parseInt(br.readLine());
            System.out.println("Client send no1=" + no1);
            
            int no2=Integer.parseInt(br.readLine());
             System.out.println("Client send no2=" + no2);
            
            int sum=no1+no2;
            
            out.println(sum);
            
            s.close();
            ss.close();
        }
        catch(Exception e)
        {
            
        }
                  
    }
    
}
