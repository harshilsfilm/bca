/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addtcp;
import java.net.*;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class AddClient {
    public static void main(String args[])
    {
        try
        {
            Socket s=new Socket("localhost",5000);
            
            BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter no1:");
            String no1=sc.next();
            
            System.out.println("Enter no2:");
            int no2=sc.nextInt();
            
            out.println(no1);
            out.println(no2);
            
            String ans=br.readLine();
            
            System.out.println("Server send sum=" + ans);
            
            s.close();
            
            
            
        }
        catch(Exception e)
        {
            
        }
    }
    
}
